var DEGREE_TO_RAD = Math.PI / 180;

/**
* Animation Class, representing the base class for animations
*
*/
class Animation{
  constructor(scene, idAnimation, duration){
    this.scene = scene;
    this.id = idAnimation;
    this.duration = duration;
  }
}
